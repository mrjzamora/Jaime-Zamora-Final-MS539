﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_project_3
{
    public class gym
    {
        public gym(string type, int cost)
        {
            Gymtype = type;
            Gymcost = cost;
        }
            public string Gymtype { get; set; }
            public int Gymcost { get; set; }
            public static int ChosenGymIndex {  get; set; }

        public override string ToString()
        {
            return string.Format("Gym type: {0}"+ Environment.NewLine + 
                                "Gym Cost: {1:C}" + Environment.NewLine,Gymtype, Gymcost);
        }


    }
}
