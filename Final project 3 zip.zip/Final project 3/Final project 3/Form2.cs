﻿using System;
using System.Windows.Forms;

namespace Final_project_3
{
    public partial class TotalCharges : Form
    {
        public TotalCharges()
        {
            InitializeComponent();
        }

        private void buttonReturn_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void Display()

        {
            BoxMultiline.Text += Form1.Gyms[gym.ChosenGymIndex].ToString();
            BoxMultiline.Text += Form1.Meal[Meal_Plan.ChosenMealPlanIndex].ToString();
            BoxMultiline.Text += "Total Cost:" + CalculateTotal().ToString("C");
        }

        private int CalculateTotal()
        {
            int gymCost = Form1.Gyms[gym.ChosenGymIndex].Gymcost;
            int mealCost = Form1.Meal[Meal_Plan.ChosenMealPlanIndex].MealPlanCost;

            return gymCost + mealCost;
        }
        private void BoxMultiline_TextChanged(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Display();
        }
    }
}
