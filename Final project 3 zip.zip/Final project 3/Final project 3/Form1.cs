﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_project_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Initialize();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public static List<gym> Gyms = new List<gym>();
        public static List<Meal_Plan> Meal = new List<Meal_Plan>();
        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            TotalCharges Form2 = new TotalCharges();
            gym.ChosenGymIndex = listGym.SelectedIndex;

            if (radioButton1.Checked)
                Meal_Plan.ChosenMealPlanIndex = 0;
            else if (radioButton2.Checked)
                Meal_Plan.ChosenMealPlanIndex = 1;
            else
                Meal_Plan.ChosenMealPlanIndex = 2;

            Form2.ShowDialog(); 



        }

        private void Initialize()
        {
            try
            {
                PopulateGym();
                PopulateMeals();
                PopulateDropDown();
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void PopulateDropDown()
        {
            listGym.Text = "Select Gym";
            foreach(gym d in Gyms)
            {
                listGym.Items.Add(d.Gymtype);   
            }
        }
        private void PopulateGym()
        {
            StreamReader sr = new StreamReader("gym.txt");
            while (!sr.EndOfStream)
            {
                string[] data = sr.ReadLine().Split(',');
                Gyms.Add(new gym(data[0], Convert.ToInt32(data[1])));
            }

            sr.Close();

        }
        private void PopulateMeals()
        {
            StreamReader sr = new StreamReader("Meals.txt");
            while (!sr.EndOfStream)
            {
                string[] data = sr.ReadLine().Split(',');
                Meal.Add(new Meal_Plan(data[0], Convert.ToInt32(data[1])));
            }

            sr.Close();
        }
    }
}
