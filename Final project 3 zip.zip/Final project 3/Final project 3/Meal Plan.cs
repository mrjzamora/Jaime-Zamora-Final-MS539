﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_project_3
{
   public class Meal_Plan
    {
        public Meal_Plan(string type, int cost)
        {
            MealPlanType = type;
            MealPlanCost = cost;
        }
        public string MealPlanType { get; set; }
        public int MealPlanCost { get; set; }
        public static int ChosenMealPlanIndex { get; set; }


        public override string ToString() 
        {
            return string.Format("Meal Type: [0]" +Environment.NewLine +
                                "Meal Cost: {1:C}" +Environment.NewLine, MealPlanType,MealPlanCost);
        }

    }
}
