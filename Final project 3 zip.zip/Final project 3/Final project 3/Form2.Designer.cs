﻿namespace Final_project_3
{
    partial class TotalCharges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BoxMultiline = new System.Windows.Forms.TextBox();
            this.buttonReturn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BoxMultiline
            // 
            this.BoxMultiline.AcceptsReturn = true;
            this.BoxMultiline.AcceptsTab = true;
            this.BoxMultiline.Location = new System.Drawing.Point(131, 76);
            this.BoxMultiline.Margin = new System.Windows.Forms.Padding(4);
            this.BoxMultiline.Multiline = true;
            this.BoxMultiline.Name = "BoxMultiline";
            this.BoxMultiline.Size = new System.Drawing.Size(753, 312);
            this.BoxMultiline.TabIndex = 0;
            this.BoxMultiline.TextChanged += new System.EventHandler(this.BoxMultiline_TextChanged);
            // 
            // buttonReturn
            // 
            this.buttonReturn.Location = new System.Drawing.Point(414, 492);
            this.buttonReturn.Margin = new System.Windows.Forms.Padding(4);
            this.buttonReturn.Name = "buttonReturn";
            this.buttonReturn.Size = new System.Drawing.Size(216, 82);
            this.buttonReturn.TabIndex = 1;
            this.buttonReturn.Text = "Return to Main Form";
            this.buttonReturn.UseVisualStyleBackColor = true;
            this.buttonReturn.Click += new System.EventHandler(this.buttonReturn_Click);
            // 
            // TotalCharges
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 684);
            this.Controls.Add(this.buttonReturn);
            this.Controls.Add(this.BoxMultiline);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "TotalCharges";
            this.Text = "Total Charges";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox BoxMultiline;
        private System.Windows.Forms.Button buttonReturn;
    }
}